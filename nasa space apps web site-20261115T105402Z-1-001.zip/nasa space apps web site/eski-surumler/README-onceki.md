# PATHFINDER-G · NASA Space Apps 2026

Challenge: Interplanetary Survival Guide: Martian Map

## Dosyalar
| Dosya | Ne |
|---|---|
| index.html | Tanıtım sayfası (Türkçe, siyah tema, 3B Mars girişi). Yayına alınacak ana sayfa. |
| simulasyon.html | Rover simülasyonu (Türkçe). Tanıtım sayfasındaki "Uygulamayı aç" buraya gider, simülasyondaki "← Tanıtım sayfası" geri döner. |
| index.src.html / simulasyon.src.html | Düzenlenecek kaynaklar. Veriler __DEM__ / __CTX__ yer tutucularıyla ayrı durur. |
| dem.b64 / ctx.b64 | Gömülü NASA verisi (JPL Mars Trek: HiRISE DEM ve CTX, 96×96). Derlerken yer tutucuların yerine konur. |
| llms.txt, robots.txt, sitemap.xml | Yapay zeka aramaları ve SEO için. sitemap.xml şablon. |
| eski-surumler/ | Önceki sürümler. |

İki HTML dosyası aynı klasörde durmalı; bağlantılar göreli.

## Yayına almadan önce doldurulacaklar
1. Ekip bölümü: index.src.html içinde "EKİP ŞABLONU" yorumunun altındaki "Ad Soyad" alanları.
2. Alan adı: index.src.html'deki "TODO after deploy" satırına canonical, og:url, og:image; sitemap.xml'de ALAN-ADINIZ; robots.txt'deki Sitemap satırı.
3. Uygulama başka bir adresteyse: index.src.html'de APP_URL.

## Simülasyon notları
- Hedefler doğrulanmış koordinatlarda: Pahrump Hills 4,676°G 137,379°D (HiRISE ESP_039280_1755), boxwork bölgesi 4,843°G 137,298°D (HiRISE PSP_001752_1750 merkezi, NASA PIA26306).
- Sol sayısı: sol başına ~100 m otonom sürüş varsayımı (SOL_M sabiti).
- Radyasyon: MSL RAD 0,67 mSv/gün, gökyüzü görüş faktörü (12 azimut) ve varsayılan +%4/km yükseklik terimiyle ölçeklenir.
- Mobilde Mars yürüyüşü paneli artık görünür.
