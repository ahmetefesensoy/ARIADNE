# PATHFINDER-G — NASA Space Apps 2026

Challenge: Interplanetary Survival Guide: Martian Map

## Files
- `index.html` — ready-to-run site (data embedded). Open it in a browser with internet access (Three.js loads from a CDN).
- `index.src.html` — same page with `__DEM__` / `__CTX__` placeholders instead of data. Edit this one.
- `dem.b64` — HiRISE Gale DEM, 96×96 8-bit, base64 (NASA JPL Mars Trek, `Gale_DEM_SMG_1m`, zoom 10, rows 538–539, cols 1805–1806).
- `ctx.b64` — CTX Gale mosaic, 96×96 8-bit grayscale, base64 (`Gale_CTX_BlockAdj_dd`, same tiles).

## Rebuild index.html after editing
```
python3 -c "s=open('index.src.html').read();open('index.html','w').write(s.replace('__DEM__',open('dem.b64').read().strip()).replace('__CTX__',open('ctx.b64').read().strip()))"
```

## Map extent
Lon 137.2852°E – 137.6367°E, Lat 4.5703°S – 4.9219°S (~20.8 km square). Bradbury Landing: 4.5895°S, 137.4417°E.

## Notes
- Elevation is calibrated from an 8-bit tile: Bradbury ≈ −4,501 m, 5.5 m per level. Approximate.
- Radiation: MSL RAD 0.67 mSv/day × sky-view factor × assumed +4%/km altitude term (illustrative).
- Mount Sharp target coordinates are approximate — verify in Mars Trek.
