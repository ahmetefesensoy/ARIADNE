#!/usr/bin/env python3
"""PATHFINDER-G derleme betiği.

Kaynak HTML dosyalarındaki yer tutucuları aynı klasördeki .b64 veri dosyalarıyla
değiştirir ve yayına hazır HTML dosyalarını üretir:

    index.src.html       -> index.html
    simulasyon.src.html  -> simulasyon.html

Kullanım:  python3 build.py        (ek paket gerekmez, Python 3.8+)
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

# yer tutucu -> veri dosyası
DATA = {
    "__DEM__": "dem.b64",      # NASA JPL Mars Trek, Gale HiRISE DEM (96×96, 8 bit)
    "__CTX__": "ctx.b64",      # NASA JPL Mars Trek, Gale MRO CTX (96×96, gri)
    "__GLOBE__": "globe.b64",  # NASA JPL Mars Trek, Viking MDIM 2.1 renkli küre (1024×512 WebP)
}
PAGES = {"index.src.html": "index.html", "simulasyon.src.html": "simulasyon.html"}


def main() -> int:
    data = {}
    for key, name in DATA.items():
        path = ROOT / name
        if not path.exists():
            print(f"HATA: {name} bulunamadı", file=sys.stderr)
            return 1
        data[key] = path.read_text(encoding="utf-8").strip()

    for src, out in PAGES.items():
        src_path = ROOT / src
        if not src_path.exists():
            print(f"atlandı: {src} yok")
            continue
        html = src_path.read_text(encoding="utf-8")
        used = [k for k in data if k in html]
        for key in used:
            html = html.replace(key, data[key])
        left = [k for k in DATA if k in html]
        if left:
            print(f"HATA: {out} içinde doldurulmamış yer tutucu: {left}", file=sys.stderr)
            return 1
        (ROOT / out).write_text(html, encoding="utf-8")
        print(f"{src} -> {out}  ({len(html) // 1024} KB, {', '.join(used) or 'veri yok'})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
